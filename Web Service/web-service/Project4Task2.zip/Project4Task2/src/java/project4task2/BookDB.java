
package project4task2;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

/**
 * A class that handles connection and insertion into MongoDB.
 * 
 * @author Xiaotong Luo
 */
public class BookDB {
    
    MongoCollection<Document> log; // the collection with all the data logs
    
    /**
     * The default constructor will establish connection with MongoDB
     */
    public BookDB() {
        String uri = "mongodb://xluo2:xluo2@cluster0-shard-00-00-te88q.mongodb.net:27017,cluster0-shard-00-01-te88q.mongodb.net:27017,cluster0-shard-00-02-te88q.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("Project4Task2");
        this.log = database.getCollection("Log");
    }
    
    /**
     * This method can convert a JSON string into a document and insert it into the collection
     * @param json 
     */
    public void insert(String json) {
        Document doc = Document.parse(json);
        log.insertOne(doc);
    }

}
