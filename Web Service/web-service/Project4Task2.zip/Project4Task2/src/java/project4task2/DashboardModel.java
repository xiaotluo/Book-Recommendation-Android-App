
package project4task2;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mongodb.client.MongoCursor;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bson.Document;

/**
 * This class demonstrates the Model for my dashboard.
 * It has methods to read the process documents in MongoDB, and calculate metrics.
 * 
 * @author Xiaotong Luo
 */
public class DashboardModel {
    
    public double fulfillment;
    public double avgApiRequestProcessTime;
    public double avgUserRequestProcessTime;
    public String popularTerm;
    public List<BookDocument> bdocs; // a list of all the documents as BookDocument object
    public double googleapisuccess;
    
    private BookDB db = null;
    
    public DashboardModel() {
        db = new BookDB(); // create a BookDB object
    }
    
    /**
     * A method to read all the documents in mongodb
     * @return list of json string representation of documents
     */
    public List<String> readDocs() {
        MongoCursor<Document> cursor = db.log.find().iterator();
        List<String> docs = new ArrayList<>();
        bdocs = new ArrayList<>();
        try {
            while (cursor.hasNext()) {
                String json = cursor.next().toJson(); // get the json representation
                JsonObject j = new Gson().fromJson(json, JsonObject.class);
                j.remove("_id");
                
                // create a BookDocument object for each document
                BookDocument bd = new BookDocument(j.get("searchTerm").getAsString(), j.get("apiStatusCode").getAsInt(),
                        j.get("totalBooks").getAsInt());
                bd.apiReplyTime = stringToTimeStamp(j.get("apiReplyTime").getAsString());
                bd.apiRequestTime = stringToTimeStamp(j.get("apiRequestTime").getAsString());
                bd.userRequestTime = stringToTimeStamp(j.get("userRequestTime").getAsString());
                bd.userReplyTime = stringToTimeStamp(j.get("userReplyTime").getAsString());
                
                docs.add(json);
                bdocs.add(bd);
            }
        } finally {
            cursor.close();
        }
        
        return docs;
    }
    
    public void processDocs(List<String> docs) {
        Map<String, Integer> searchTerms = new HashMap<>(); // store the searchterms and frequency
        
        int totalFulfillment = 0;
        int totalSuccess = 0;
        int totalRecords = docs.size();
        Long totalUserRequestProcessTime = new Long(0);
        Long totalApiRequestProcessTime = new Long(0);
        
        for (int i = 0; i < docs.size(); i++) {
            JsonObject doc = new Gson().fromJson(docs.get(i), JsonObject.class); // convert json string to json object
            
            // increment search term frequency
            String searchTerm = doc.get("searchTerm").getAsString();
            int freq = searchTerms.getOrDefault(searchTerm, 0);
            freq++;
            searchTerms.put(searchTerm, freq);
            
            int totalItems = doc.get("totalBooks").getAsInt();
            if (totalItems > 0) {
                totalFulfillment++; // successful fulfillment
            }
            int status = doc.get("apiStatusCode").getAsInt();
            if (status == 200) {
                totalSuccess++; // successful request to google books api
            }
            
            // Calculate time difference for the two processes
            String userRequestTime = doc.get("userRequestTime").getAsString();
            String userReplyTime = doc.get("userReplyTime").getAsString();
            Long userRequestProcessTime = getLatency(userRequestTime, userReplyTime);
            totalUserRequestProcessTime += userRequestProcessTime;
            
            String apiRequestTime = doc.get("apiRequestTime").getAsString();
            String apiReplyTime = doc.get("apiReplyTime").getAsString();
            Long apiRequestProcessTime = getLatency(apiRequestTime, apiReplyTime);
            totalApiRequestProcessTime += apiRequestProcessTime;
        }
        
        // calculate operations analytics
        fulfillment = totalFulfillment*1.0/totalRecords;
        avgUserRequestProcessTime = totalUserRequestProcessTime*1.0/totalRecords;
        avgApiRequestProcessTime = totalApiRequestProcessTime*1.0/totalRecords;

        getPopularTerm(searchTerms);
        googleapisuccess = totalSuccess*1.0/totalRecords;
    }
    
    /**
     * Get time difference between two timestamp
     * @param requestTime
     * @param replyTime
     * @return time difference in milliseconds
     */
    private Long getLatency(String requestTime, String replyTime) {
        
        Long latency = new Long(0);
        java.sql.Timestamp requestTimeStamp = stringToTimeStamp(requestTime);
        java.sql.Timestamp replyTimeStamp = stringToTimeStamp(replyTime);
        latency = replyTimeStamp.getTime() - requestTimeStamp.getTime();
        
        return latency;
    }
    
    /**
     * Convert a datetime string to timestamp type (from stackoverflow, details in writeup)
     * @param str
     * @return timestamp
     */
    private static java.sql.Timestamp stringToTimeStamp (String str) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        java.sql.Timestamp time = new java.sql.Timestamp(System.currentTimeMillis());
        try {
            Date parsed = dateFormat.parse(str);
            time = new java.sql.Timestamp(parsed.getTime());
        } catch (ParseException ex) {
            Logger.getLogger(DashboardModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return time;
    }
    
    /**
     * Get the most popular search term
     * @param searchTerms 
     */
    private void getPopularTerm(Map<String, Integer> searchTerms) {
        
        int max = 0;
        for (String word : searchTerms.keySet()) {
            if (searchTerms.get(word) > max) {
                max = searchTerms.get(word);
                popularTerm = word;
            }
        }
    }
    
}
