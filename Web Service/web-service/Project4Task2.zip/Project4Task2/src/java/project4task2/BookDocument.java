
package project4task2;

/**
 * This class demonstrates the fields (information extracted) for a document stored in MongoDB.
 * It shows the structure of a document.
 * @author Xiaotong Luo
 */
public class BookDocument {
    
    public String searchTerm;
    
    public java.sql.Timestamp userRequestTime;
    
    public java.sql.Timestamp apiRequestTime;
    
    public java.sql.Timestamp apiReplyTime;
    
    public int apiStatusCode;
    
    public int totalBooks;
    
    public java.sql.Timestamp userReplyTime;
    
    public BookDocument(String searchTerm, java.sql.Timestamp requestTime) {
        this.searchTerm = searchTerm;
        this.userRequestTime = requestTime;
    }
    
    public BookDocument(String searchTerm, int apiStatusCode, int totalBooks) {
        this.searchTerm = searchTerm;
        this.apiStatusCode = apiStatusCode;
        this.totalBooks = totalBooks;
    }
    
}
