
package project4task2;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This class is the controller for the my dashboard.
 * When the user visits the dashboard web page, the controller will call methods in DashboardModel.java
 * to read and process all documents in MongoDB to calculate operations analytics.
 * The operations analytics and data logs information will be displayed in dashboard.java.
 * 
 * @author Xiaotong Luo
 */
@WebServlet(name = "Dashboard", urlPatterns = {"/Dashboard"})
public class Dashboard extends HttpServlet {

    DashboardModel dm = null;
    
    @Override
    public void init() {
        dm = new DashboardModel();
    }
    
    /**
     * Handles the HTTP <code>GET</code> method.
     * When the user visits the dashboard web page (GET request), the controller will call methods in DashboardModel.java
     * to read and process all documents in MongoDB to calculate operations analytics.
     * The operations analytics and data logs information will be displayed in dashboard.java.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        dm.processDocs(dm.readDocs()); // read and process documents in mongodb
        
        // format the results displayed
        String fillrate = String.format("%.1f", dm.fulfillment*100); // format percentage metric
        String apiSuccess = String.format("%.1f", dm.googleapisuccess*100); // format percentage metric
        String avgUserRequestProcessTime = String.format("%.2f", dm.avgUserRequestProcessTime);
        String avgApiRequestProcessTime = String.format("%.2f", dm.avgApiRequestProcessTime);
        
        // set the information displayed in view
        request.setAttribute("fillrate", fillrate);
        request.setAttribute("topWord", dm.popularTerm);
        request.setAttribute("avgUserRequestProcessTime", avgUserRequestProcessTime);
        request.setAttribute("avgApiRequestProcessTime", avgApiRequestProcessTime);
        request.setAttribute("successRate", apiSuccess);
        request.setAttribute("docs", dm.bdocs);
        
        String nextView = "dashboard.jsp";
        // Transfer control over the the correct "view"
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
    
}
