
package project4task2;

import java.util.ArrayList;
import java.util.List;

/**
 * This class demonstrates the fields (information extracted) for a list for books.
 * It shows the structure of the JSON data returned to the mobile phone user.
 * @author Xiaotong Luo
 */
public class BookList {
    
    int size; // number of books 
    
    List<Book> bookList; // a list of 5 Book objects
    
    public BookList() {
        bookList = new ArrayList<>();
    }
    
}
