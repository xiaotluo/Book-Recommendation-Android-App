
package project4task1;

import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This class demonstrates the Controller for this web project.
 * This class receives the get request from the user and gets the searchTerm
 * and calls the doBooksSearch method in model class to search Google books for related books' information
 * and returns the data formatted in model to the user.
 * 
 * @author Xiaotong Luo
 */
@WebServlet(name = "BookServlet", urlPatterns = {"/BookServlet/*"})
public class BookServlet extends HttpServlet {
    
    BookModel bm = null;  // The "business model" for this app

    // Initiate this servlet by instantiating the model that it will use.
    @Override
    public void init() {
        bm = new BookModel();
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     * It receives the get request from the user and get the searchTerm
     * and call the doBooksSearch method in model class to search Google books for related books' information
     * 
     * @param request servlet request
     * @param response servlet response
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        
        try{
            // get the search parameter if it exists
           String search = (request.getPathInfo()).substring(1);

           if (search != null) {

               String extractInfo = bm.doBooksSearch(search);

               // Things went well so set the HTTP response code to 200 OK
               response.setStatus(200);

               // tell the client the type of the response and it is the type that client wants
               response.setContentType("application/json");
               response.getWriter().write(extractInfo);
               
           }
        } catch (IOException ex) {
            response.setStatus(500);
        }
        
    }
}
