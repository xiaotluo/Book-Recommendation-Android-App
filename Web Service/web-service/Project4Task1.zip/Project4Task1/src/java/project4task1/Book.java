
package project4task1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * This class demonstrates the fields (information extracted) for a book. 
 * @author Xiaotong Luo
 */
public class Book {
    
    String title;
    
    String author;
    
    String imgURL;
    
    String publishedTime;
    
    String infoURL;
    
    /**
     * Constructor for a book object
     * @param title
     * @param author
     * @param imgURL
     * @param year
     * @param infoURL 
     */
    public Book(String title, String author, String imgURL, String year, String infoURL) {
        this.title = title;
        this.author = author;
        this.imgURL = imgURL;
        this.infoURL = infoURL;
        this.publishedTime = year;
    }
    
    /**
     * Override toString() method to return a JSON representation of all of the fields of this book.
     * @return a JSON representation of all of the fields of this book
     */
    @Override
    public String toString() {
        Gson gsonObj = new GsonBuilder().create();
        return gsonObj.toJson(this);
    }
    
}
