
package project4task1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * This class demonstrates the Model for this web project. 
 * The model class can search related books' information via Google Books API given a search term
 * and then extract information needed, and format and return the results.
 * 
 * @author Xiaotong Luo
 */
public class BookModel {
    
    /**
     * This method takes an search string and search on Google Books API
     * @param search
     * @return JSON data
     */
    public String doBooksSearch(String search) {
        
        search = search.replaceAll(" ", "+");
        String response = "";
        
        String booksURI = "https://www.googleapis.com/books/v1/volumes?q=" + search + "&maxResults=5"; // search on google books
        
        response = fetch(booksURI); // fetch results
        
        return extractInfo(response); // extract information and return results
        
    }
    
    /**
     * Establish http connection and fetch results
     * @param urlString
     * @return all JSON data fetched
     */
    public String fetch(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which 
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server

            connection.setRequestMethod("GET");
            // tell the server what format we want back
            connection.setRequestProperty("Content-Type", "application/json");
            
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();
            
        } catch (IOException e) {
            System.out.println("Eeek, an exception");
            // Do something reasonable.
        }
        
        return response;
        
    }
    
    /**
     * Extract information needed in JSON data
     * @param json
     * @return formatted JSON data
     */
    public String extractInfo(String json) {
        
        if (json.isEmpty()) { // when request to googble books fails
            return "";
        }
        
        JsonObject jobj = new Gson().fromJson(json, JsonObject.class); // create a json object for the json string

        int total = jobj.get("totalItems").getAsInt();
        
        BookList results = new BookList(); // create a booklist object
        
        if (total == 0) { // check if there are results found for the search term
            results.size = 0;
            Gson gsonObj = new GsonBuilder().disableHtmlEscaping().create();
            String jsonresults = gsonObj.toJson(results);
            return jsonresults;
        }
        JsonArray books = jobj.getAsJsonArray("items");

        for (JsonElement book : books) { // get information for the 5 books
                JsonObject bookObj = book.getAsJsonObject();
                JsonObject volumeInfo = bookObj.getAsJsonObject("volumeInfo");
                String title = volumeInfo.get("title").getAsString();

                StringBuilder sb = new StringBuilder();
                if (volumeInfo.has("authors")) { // combining multiple authors
                    JsonArray authors = volumeInfo.get("authors").getAsJsonArray();
                    for (int i = 0; i < authors.size(); i++) {
                        String author = authors.get(i).getAsString();
                        if (i < authors.size() - 1) {
                            sb.append(author).append(", ");
                        } else {
                            sb.append(author);
                        }
                    }                    
                } else {
                    sb.append("Not Available"); // if no authors found for the book
                }
                String authorsAll = sb.toString();
                
                String year = "Not Available"; // default for no publication time found for the book
                
                if (volumeInfo.has("publishedDate")) {
                    year = volumeInfo.get("publishedDate").getAsString(); // get publication time for the book
                }
                
                
                String thumnail = "";
                if (volumeInfo.has("imageLinks")) {
                    JsonObject thumnails = volumeInfo.get("imageLinks").getAsJsonObject();
                    thumnail = thumnails.get("thumbnail").getAsString(); // get thumbnail image link
                } else {
                    thumnail = "https://www.workman.com/assets/images/product-default.png"; // default picture if no pictures for the book
                }
                
                String infoLink = "https://books.google.com/"; // default link if no infoLink for the book
                if (volumeInfo.has("infoLink")) {
                    infoLink = volumeInfo.get("infoLink").getAsString(); // get information link for the book
                }

                Book newBook = new Book(title, authorsAll, thumnail, year, infoLink);
                results.bookList.add(newBook);
        }
        
        results.size = results.bookList.size(); // set the size to be the size of the list of books
        
        Gson gsonObj = new GsonBuilder().disableHtmlEscaping().create();
        String jsonresults = gsonObj.toJson(results); // create a json representation of the booklist object
        
        return jsonresults;
    }
    
}
